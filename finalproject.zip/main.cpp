#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>

using namespace std;

const int ALPHABET_SIZE = 26;
const int hashsize=1000;

struct hash_node
{
    string word;
    hash_node*next;
    hash_node*prev;
};
class HashMap {
public:
    hash_node **hashtable;

    HashMap() {
        hashtable = new hash_node *[hashsize];;
        for (int i = 0; i < hashsize; i++) {
            hashtable[i] = nullptr;
        }
    }

    ~HashMap()
    {
        delete[] hashtable;
    }

    int HashFunc(int key)
    {
        return key % hashsize;
    }

    void find(string word)
    {
        int hash=0;
        for(char s:word){
            hash+=int(s);
        }
        int hash_val=HashFunc(hash);
        bool flag=false;
        hash_node* entry=hashtable[hash_val];
        if(entry != nullptr)
        {
            while(entry != nullptr)
            {
                if (entry->word==word)
                {
                    flag=true;
                }
                if(flag)
                {
                    cout<<"Word founded : "<<entry->word<<endl;
                    break;
                }
                entry=entry->next;
            }
        }
        if(!flag)
        {
            cout<<"No word found"<<endl;
        }
    }

    void add(string word)
    {
        int hash=0;
        for(char s:word){
            hash+=int(s);
        }
        int hash_val=HashFunc(hash);
        hash_node* entry=hashtable[hash_val];
        hash_node* preventry=nullptr;
        if(entry== nullptr)
        {
            entry=new hash_node;
            entry->word=word;
            entry->next= nullptr;
            entry->prev= nullptr;
            hashtable[hash_val]=entry;
        }else{
            while (entry!= nullptr) {
                preventry = entry;
                entry = entry->next;
            }
            entry=new hash_node;
            entry->word=word;
            entry->next= nullptr;
            preventry->next=entry;
            entry->prev=preventry;
        }
    }
    void traverse(){
        hash_node *curr=nullptr;
        for(int i=0;i<1000;i++){
            curr=hashtable[i];
            while(curr!=NULL){
                cout<<curr->word<<endl;
                curr=curr->next;
            }
        }
    }
    void deletenode(string word){
        int hash=0;
        int hash_search=0;
        for(char s:word){
            hash+=int(s);
        }
        int hash_val=HashFunc(hash);
        hash_node* entry=hashtable[hash_val];
        hash_node* preventry=nullptr;

        if(entry== nullptr){
            cout<<"No word exist"<<endl;
        }else{
            while (entry->word!=word&&entry->next!=nullptr) {
                entry=entry->next;
            }
            if(entry->word==word) {
                if(entry->next==nullptr){
                    entry->prev->next=nullptr;
                    entry->prev = nullptr;
                    entry->next = nullptr;
                    cout << "Word deleted" << endl;
                    delete entry;
                }
                else if(entry->prev==nullptr){
                    entry->next->prev=nullptr;
                    hashtable[hash_val]=entry->next;
                    entry->prev = nullptr;
                    entry->next = nullptr;
                    cout << "Word deleted" << endl;
                    delete entry;
                }
                else {
                    entry->next->prev = entry->prev;
                    entry->prev->next = entry->next;
                    entry->prev = nullptr;
                    entry->next = nullptr;
                    cout << "Word deleted" << endl;
                    delete entry;
                }
            }
            else{
                cout<<"The Word Doesnt Exist"<<endl;
            }
        }
    }
};

struct TrieNode
{
    struct HashMap *children[ALPHABET_SIZE];
};


struct TrieNode* getNode()
{
    struct TrieNode *pNode;
    pNode = new TrieNode;
    HashMap *hash= nullptr;

    for (int i = 0; i < ALPHABET_SIZE; i++)
    {
        hash=new(HashMap);
        pNode->children[i] = hash;
    }

    return pNode;
}

string lowercase(string s)
{
    char c[s.length()];
    string test="";
    locale loc;
    for(int i=0;i<s.length();i++)
    {
        test+=(tolower(s[i],loc));
    }
    return test;
}

int main()
{
    int n = 0;
    fstream myfile;
    string line="",filename;
    vector<string> str;
    filename="C:\\Users\\ROG\\CLionProjects\\finalproject\\words_alpha.txt";
    myfile.open(filename.c_str());
    if (myfile.is_open())
    {
        while (myfile>>line)
        {
            str.push_back(line);
            n++;
        }
        myfile.close();
    }
    else cout << "Unable to open file";

    struct TrieNode *root = getNode();
    for(string s:str){
        int index=int(s[0]-97);
        root->children[index]->add(s);
    }

    string out, in;
    int op = 1;
    int firstword;
    while(op){
        cout<<"1. Insert new word\n2. Search word\n3. Display all words\n4. Delete a word\n5. Exit Program"<<endl;
        cin >>op;
        switch(op){
            // To insert new string
            case 1:
                cout<<"insert new word:";
                cin >>in;
                in=lowercase(in);
                firstword=int(in[0]-97);
                root->children[firstword]->add(in);
                break;

                // To search a string in TST
            case 2:
                cout<<"What word you want to search:";
                cin >>in;
                in=lowercase(in);
                firstword=int(in[0]-97);
                root->children[firstword]->find(in);
                break;

                // To traverse TST
            case 3:
                cout<<"What word do you want to traverse"<<endl;
                cin>>in;
                in=lowercase(in);
                firstword=int(in[0]-97);
                root->children[firstword]->traverse();
                break;

                // To break the loop\

            case 4:
                cout<<"What word do you want to delete"<<endl;
                cin>>in;
                in=lowercase(in);
                firstword=int(in[0]-97);
                root->children[firstword]->deletenode(in);
                break;
            case 5: op = 0;
                break;

        default:cout <<"Invalid Option!!!\n";
            op = 1;
        }
    }
    return 0;
}